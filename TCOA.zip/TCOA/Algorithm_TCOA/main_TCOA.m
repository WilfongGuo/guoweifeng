clc,clear
%**************************************Part1:load data***********************

network_fileName = 'network.txt';
constrained_nodes_fileName = 'constrained_nodes.txt';
targets_fileName = 'targets.txt';

%************************************Part2:main part***************************

[driver_result] = Greedy_OBP_MCMC(network_fileName,constrained_nodes_fileName,targets_fileName);

%************************************Part3:Results***************************

save TCOA_result