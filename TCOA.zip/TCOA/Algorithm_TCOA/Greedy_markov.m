function [ M,result ] = Greedy_markov( F,Z,g,N,NM )
%F:��ʼƥ��
%CC:target node 
%Z��ԭʼ���ӹ�ϵ
%E����ʱ���ӹ�ϵ
%g���ڽӾ���
%N�������ģ
%NM�����������̴���
f=[];
f(:,1)=[1:N]';
f(:,2)=F(1:N,1);
PP=[];kk=1;
for i=1:length(f)
    if f(i,2)~=0
        PP(kk,1)=f(i,1);PP(kk,2)=f(i,2)-N;
        kk=kk+1;
    end
end


M=zeros(N);
[row_P,colunm_P]=size(PP);
for i=1:row_P
    M(PP(i,1),PP(i,2))=1;
end
% Z=E;
% **************************************************************************
    %��M�������ӹ�ϵm
    
%  AdjacentMatrix2File(M,'m')
%  m=load('m.txt');
m=PP;
 m(:,2)= m(:,2)+length(M);m=m(:,1:2);
 
  n=10;  %�����������Ҫ����
    
    
[ M1] = Markov_sampling( m,Z,M);
% M1=result;
MN=M1;
if length(M1)<NM
    
    
    
    [H3,H4]=find(g~=0);
         Z=[];
         Z(:,1)=H4;Z(:,2)=H3+N;
    MM=M1;
mark=zeros(length(MN),1);
    for i=1:length(MN)
        
         M=MN{i,1};
          h1=sum(M);h2=sum(M,2);
    h=h1'.*h2;
    hj=find(h>1);
     if length(hj)~=0
        mark(i,1)=1;
     end
    end
    MN=MN(find(mark==0));




    for i=1:length(MN)
        i
         M=MN{i,1};     
         [H1,H2]=find(M~=0);
         m=[];
         m(:,1)=H1;m(:,2)=H2+N;
         
         [ M2] = Markov_sampling( m,Z,M);
         
         
         MM=[MM;M2];
         %��֤M1�и���Ԫ�ز�һ��
mark=zeros(length(MM),1);
for i=1:length(MM)
    if mark(i)~=1
    for j=i+1:length(MM)
        if mark(j)~=1
            if isequal(MM{i,1},MM{j,1})
                mark(j)=1;
            end
        end
    end
    end
end
result=MM(find(mark==0));


%��֤result���Ǻ�����ƥ��
mark=zeros(length(result),1);
for i=1:length(result)
    
    M1=result{i,1};
    h1=sum(M1);h2=sum(M1,2);
    h=h1'.*h2;
    hj=find(h>1);
    if length(hj)~=0
        mark(i,1)=1;
    end
end
 result=result(find(mark==0));   
 
         if length(result)>NM
             break;
         end
    end
    
end
   



%�ڶ��μ��

M1=result;
MN=M1;
if length(M1)<NM
    [H3,H4]=find(g~=0);
         Z=[];
         Z(:,1)=H4;Z(:,2)=H3+N;
    MM=M1;
mark=zeros(length(MN),1);
    for i=1:length(MN)
        
         M=MN{i,1};
          h1=sum(M);h2=sum(M,2);
    h=h1'.*h2;
    hj=find(h>1);
     if length(hj)~=0
        mark(i,1)=1;
     end
    end
    MN=MN(find(mark==0));




    for i=1:length(MN)
        
         M=MN{i,1};     
         [H1,H2]=find(M~=0);
         m=[];
         m(:,1)=H1;m(:,2)=H2+N;
         
         [ M2] = Markov_sampling( m,Z,M);
         MM=[MM;M2];
         %��֤M1�и���Ԫ�ز�һ��
mark=zeros(length(MM),1);
for i=1:length(MM)
    if mark(i)~=1
    for j=i+1:length(MM)
        if mark(j)~=1
            if isequal(MM{i,1},MM{j,1})
                mark(j)=1;
            end
        end
    end
    end
end
result=MM(find(mark==0));


%��֤result���Ǻ�����ƥ��
mark=zeros(length(result),1);
for i=1:length(result)
    
    M1=result{i,1};
    h1=sum(M1);h2=sum(M1,2);
    h=h1'.*h2;
    hj=find(h>1);
    if length(hj)~=0
        mark(i,1)=1;
    end
end
 result=result(find(mark==0));   
 
         if length(result)>NM
             break;
         end
    end
    
end



