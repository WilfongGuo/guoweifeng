function [driver_result] = Greedy_OBP_MCMC( network_fileName,constrained_nodes_fileName,targets_fileName )
%FUNCTION:Find optioanl drivers to target control a system by minimizing the total number of driver nodes 
%and meantime maximizing the number of constrained nodes among those drivers. 
%Inputs:
%      network_fileName---The network structure consists the edges which nodes are connected.
%      constrained_nodes_fileName---A certain well-selected network nodes are expected that more driver nodes are consistent with.
%      targets_fileName-----A subset of nodes are expected to be controlled from any initial state to any desired state.
%Output:
%      driver_result----the optional driver nodes for target controlling complex networks in each Markov samplings.
%****************************load data***************************************
z=load(network_fileName);
BB=load(constrained_nodes_fileName);
CC=load(targets_fileName);
%****************************setting parameters***************************************
N=max(max(z));
B=[1:N]';
NM=1;%The number of candidate matches produced each time 
num_max=5;%Random sampling num_max times, to observe the impact of indicators 
% c=5;%The parameter in Markov samplings
no_change_num_max=5;
c=10;
eff_mcmc_o=[];
i=1;j=1;    
C=CC;
B_fda=BB;
%******************************Greedy algorithm and OBP**************************

L=[];
[ final_predict_driver0,omiga0,TK0,kexi1, kexi2, kexi3, kexi4 ,length_lower_bound] = Markov_chain_driver( z,B,B_fda,C,NM );
Kexi1(i,j)=kexi1;Kexi2(i,j)=kexi2;eff_Greedy_o(i,j)=(1-kexi1+kexi2)/2;
Kexi3(i,j)=kexi3;Kexi4(i,j)=kexi4;eff_OBP_o(i,j)=(1-kexi3+kexi4)/2;
Lower_bound(i,j)=length_lower_bound/length(C);

 %*******************************MCMC*******************************************
 Y=[];Y1=[];Y2=[];Y3=[];
Y(1,1)=omiga0;YY{1,1}=final_predict_driver0;
Y1(1,1)=kexi4;Y2(1,1)=kexi3;Y3(1,1)=(1-kexi3+kexi4)/2;
ind_max=1;num_iter=2;no_change_num=1;    
while ind_max
    
  % generate new Markov chain
  % Assume that the length of Markov chain(TK0) is k��randomly choose a
  % edge��replace it by a new edge��untill generate a new markov chaon

  [final_predict_driver1,omiga1,TK1] = New_Markov_chain_driver( z,B,B_fda,C,NM,TK0);
  
% monto carlo���֣�
  %Monto carlo simulation��accept probability

  p=min(1,exp(c*(omiga1-omiga0)));
  r=rand;
  if r<=p
      Y1(num_iter,1)=max(sum(ismember(final_predict_driver1,B_fda))/length(final_predict_driver1));
      Y2(num_iter,1)=min(length(final_predict_driver1)/length(C));
      Y3(num_iter,1)=max((1-length(final_predict_driver1)/length(C)+sum(ismember(final_predict_driver1,B_fda))/length(final_predict_driver1))/2);
      Y(num_iter,1)=omiga1;
      
      TK0=TK1;

    
      omiga0=omiga1;
      final_predict_driver0=final_predict_driver1;
  end
  
  if r>p
      Y1(num_iter,1)=max(sum(ismember(final_predict_driver0,B_fda))/length(final_predict_driver0));
      Y2(num_iter,1)=min(length(final_predict_driver0)/length(C));
      Y3(num_iter,1)=max((1-length(final_predict_driver0)/length(C)+sum(ismember(final_predict_driver0,B_fda))/length(final_predict_driver0))/2);
      Y(num_iter,1)=omiga0;
%       YY{num_iter,1}=final_predict_driver0;
       TK0=TK0; 
       omiga0=omiga0;
       final_predict_driver0=final_predict_driver0;
       
  end
  
   %**************** **************

   if num_iter>2
   oniga_now=max(Y);
   oniga_pre=max(Y(1:num_iter-1,:));
   if oniga_pre==oniga_now
   no_change_num=no_change_num+1;
   end
   end
   

   YY{num_iter,1}=final_predict_driver0;
   num_iter=num_iter+1;
  
   if num_iter>num_max
      ind_max=0;
   end
   
   if no_change_num>no_change_num_max
      ind_max=0;
   end
  
end

if c==10
Kexi5_5(i,j)=min(Y2);Kexi6_5(i,j)=max(Y1);
eff_mcmc_5_o{i,j}=Y;
driver_5=YY;
end


%save the results

driver_result=driver_5;


end

