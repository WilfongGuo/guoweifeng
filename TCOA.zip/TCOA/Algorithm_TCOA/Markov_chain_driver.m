function [  final_predict_driver,omiga,TK,kexi1, kexi2, kexi3, kexi4,length_lower_bound ] = Markov_chain_driver( z,B,B_fda,C,NM )
%Function:obtain the Markov chain to obtain the driver set
%Input:z----network
%      B----all nodes
%      B_fda--constrained control nodes
%      C------targeted nodes
%      NM=1 Markov chain parameter
%Output��
%      final_predict_driver--predicted driver set
%      omiga----the weight of Markov chain
%      TK-------new Markov chain
 N=max(max(z));
 [TK,RR] = check_Greedy( z,C,NM );
 lower_bound=setdiff(RR{1,1},TK{1,1}(:,2));
 length_lower_bound=length(lower_bound);

 [driver_set] = find_driver( TK,RR );
 [check_B,CC] = check_subspace( TK,B,N );

 for i_c=1:length(C)
     check_B(C(i_c,1),C(i_c,1))=1;
 end
 
 
[dn,fraction,weight]=check_IIP2(B_fda,check_B,C); 


 kexi1=length(driver_set)/length(C);
 kexi2=sum(ismember(driver_set,B_fda))/length(driver_set);
 kexi3=length(dn)/length(C);
 kexi4=sum(ismember(dn,B_fda))/length(dn);
 
%find new potential driver nodes
all_dn=[];
inter_dn=dn;
all_fda_num=[];
predict_driver=dn;
b = unique ( predict_driver','rows');
 final_predict_driver=b';
omiga=sum(ismember(dn,B_fda))-2*length(dn);

   
end

