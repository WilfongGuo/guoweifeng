function [ check_B,CC] = check_subspace( TK,B,N )
%Fuction:Identify the target controllable subspace
%  Inputs:Tk----The Markov chain
%         B--all nodes
%         N---the number of nodes
%  Oytput:
%         check_B---the target controllable subspace
   first_element=TK{1,1};
   for  j=1:length(first_element(:,2))
       
       index_j=first_element(j,2);
       xx=index_j;
       search=first_element(j,1);
%        check_B(index_j,search)=1;
       MV(1,1)=search;
  for i=2:length(TK)
      
      element=TK{i,1};
      [x,y]=find(element(:,2)==search);
      if length(x)==0
          break;
      end
      zx=element(:,1);
      search=zx(x,1);
      MV(i,1)=search;
%         check_B(index_j,search)=1;
  end
  

  target_sub_space{j,1}=[index_j;MV];
   end
   
   
  check_B=zeros(N);
  for i=1:length(target_sub_space)
      ele=target_sub_space{i,1};
      for j=1:length(ele)
          if ismember(ele(j,1),B)~=0
          check_B(ele(1,1),ele(j,1))=1;
          end
      end
  end
   
   
 %ʵ���ϣ���һ�������γ�һ������manner������Ӱ�����֮��Ŀ��Ʒ�ʽ
[row_TK,colunm_row]=size(TK);%��һ��ûʲô��
 for k=1:1
     each_manner=TK{k,1};
     %��ÿһ����each_manner���ҿ��Ʒ�ʽ
     [row_manner,colunm_manner]=size(each_manner);  
     manner_left=each_manner(:,1);manner_right=each_manner(:,2);
     
     for kj=1:row_manner
         each_node_left= manner_left(kj,1);
         ind_each_node_left=find(manner_left==each_node_left);
         search=manner_right(ind_each_node_left,1);
         
         inde=2;qw=1;

         while qw
            
              check_B(each_node_left,search)=1;
              [x,y]=find(manner_left==search);
              if length(x)==0
                  qw=0;
              end
              inde=inde+1;
             search= manner_right(x,1);
             
            if inde>row_manner+1
                qw=0;
            end
         end
     end
     
 end
  
CC=TK{1,1}(:,2);

end

