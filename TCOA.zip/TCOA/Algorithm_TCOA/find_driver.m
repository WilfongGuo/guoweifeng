function [driver_set] = find_driver( TK,RR )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
all_driver=[];
for i=1:length(RR)
    all_nodes=RR{i,1};
    matched_nodes=TK{i,1};
    matched_nodes=matched_nodes(:,2);
    driver_nodes=setdiff(all_nodes,matched_nodes);
    all_driver=[all_driver;driver_nodes];

end

driver_set=unique(all_driver);
