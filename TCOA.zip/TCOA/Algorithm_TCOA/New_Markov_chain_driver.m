function  [final_predict_driver,omiga,TK] = New_Markov_chain_driver( z,B,B_fda,C,NM,TK0)
%%
%function:
%        Based on the previous Markov chain,obtain the new Markov chain
%        Note��choose v uniformly at random from Mt and choose w
%                 uniformly from the matched links to be replaced ,M(t+1)=M(t)-{v}+{w}          
%****************************************************************************************
%Input:
%      z----the connection list
%      B----ALL nodes in the network
%      B_fda--constrained control nodes(individual mutations)
%      C------targeted genes
%      NM=1��the default parameter in the Markov chain sampling
%      TK0----previous Markov chain
%****************************************************************************************
%Output��
%      final_predict_driver1------new driver set
%      omiga1----the weight of Markov chain
%      TK1-------the new Markov chain
%****************************************************************************************
[row_TK0,colunm_TK0]=size(TK0);
p1 = randperm(row_TK0)';
index=1;i=1;
while index
    k=p1(i,1)
   [TK,eva_index] = check_re_Greedy( z,C,NM,TK0,k);
  

if eva_index==0
    i=i+1;
end

if eva_index==1
    break;
end
    

if i>length(p1)
    break;
end

end

 N=max(max(z));
 [check_B,CC] = check_subspace( TK,B,N );
 
 
 [dn,fraction,weight]=check_IIP2(B_fda,check_B,C); 

dn=dn';;
% inter_dn=all_dn;
 predict_driver=dn;
b = unique ( predict_driver','rows');
 final_predict_driver=b';
% driver_set=predict_driver(:,1);
omiga=sum(ismember(dn,B_fda))-2*length(dn);

   
end


