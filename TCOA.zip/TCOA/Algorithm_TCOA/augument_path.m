function [z,u]=augument_path(x,y,ZZ,Z1,N)
%fuction:find the augument path from x to y
%Input:x,y--two nodes
%      ZZ--mated edges
%      Z1---the original edges
%Output:z--augument path
%      u--the index indicts whether we find the augument path
nm=2*N;WW=zeros(nm);
[uy,ut]=size(ZZ);
if uy~=0
    
    
for i=1:uy
    WW(ZZ(i,1),ZZ(i,2))=1;
    WW(ZZ(i,2),ZZ(i,1))=1;
end


q=1;
 g=WW;g=sparse(g);[aa1 bb1]=components(g);
 
 if aa1(x,1)~=aa1(y,1)
     q=0;
     z=[];u=inf;
 end
 
 
if q

[aa,bb]=find(aa1(:,1)==aa1(x,1));JH=[];
for i=1:length(aa)
    JH(i,1)=i;JH(i,2)=aa(i,1);
end


comp=JH(:,2);
W=WW(comp,comp);




W(W==0)=inf;

[x1,y1]=find(JH(:,2)==x);xx=JH(x1,1);
[x2,y2]=find(JH(:,2)==y);yy=JH(x2,1);



W=sparse(W);
[d pred] = shortest_paths(W,xx);
z=yy;
while pred(1,z(1,1))~=xx
    z=[pred(1,z(1,1));z];
    
end
 z=[pred(1,z(1,1));z];   

  JJ=[];
  
  
  for i=1:length(z)
      [x3,y3]=find(JH(:,1)==z(i,1));
      JJ(i,1)=JH(x3,2);
  end
  z=JJ;

U=[z(1:length(z)-1,1) z(2:end)];uu=[];
[c,d]=size(U);

uni_Z1=unique(Z1,'rows');
for k=1:c
    
    xc=max(U(k,:));
    [x1,y1]=find(uni_Z1(:,1)==min(U(k,:)));[x2,y2]=find(uni_Z1(:,2)==xc);
    xxx=intersect(x1,x2);
    [x_ind,~]=size(xxx);
    if x_ind~=0
    
        uu(k,1)=uni_Z1(xxx,3);
        
    end
    
end
u=sum(uu);


end


end


if uy==0
     z=[];u=inf;
end

end

