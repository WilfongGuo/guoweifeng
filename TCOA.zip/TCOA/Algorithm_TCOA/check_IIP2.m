function [dn1,fraction1,weight]=check_IIP2(B,check_B,CC) 
%%Function:calculate the minimum cover set
% Input��
%     check_B:target controllable subspace of each gene
% Output��
%     dn1----the drive nodes
%     fraction1 and weight----the weight of the driver nodes
%x = bintprog(f,A,b,Aeq,beq) solves the preceding problem with the additional equality constraint
% min f'*x
% A*x<=b,
% Aeq��x = beq,x binary
C=CC;
for i=1:length(C)
    check_B(C(i,1),C(i,1))=1;
end


[row_check_B,colunm_check_B]=size(check_B);
a=ones(row_check_B);b=a(:,1);c=diag(a(1,:));

f0 = b;% min f'*x

xc=zeros(row_check_B,1);
xc(B,1)=1;


add_f=ones(length(B),1);
f=[2*f0;-add_f];


N1=row_check_B+length(B);
A=[-check_B zeros(row_check_B,length(B))];
% A=[-check_B];
B1=zeros(row_check_B,1);
% C=CC;
for jg=1:length(C)
    B1(C(jg,1),1)=-1;
end

Aeq=zeros(length(B),N1);
for i=1:length(B)
    Aeq(i,B(i,1))=1;
    Aeq(i,row_check_B+i)=-1;
end
Beq=zeros(length(B),1);


OptionsBint=optimset('MaxRLPIter',100000,'NodeSearchStrategy','bn',...
    'MaxTime',inf,'TolXInteger', 1.e-10);
x= bintprog(f,A,B1,Aeq,Beq,[],OptionsBint);
x=full(x);
xx=x(1:row_check_B,1);

index=find(xx(:,1)==1);
M=length(index);


ddn= ones(1,M);
for i=1:M
 ddn(1,i)=index(i,1);
end
dn1=ddn;
fraction1=M/length(C);
weight=sum(ismember(dn1,B))-2*length(dn1);

end

