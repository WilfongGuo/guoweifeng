function [ TK,RR] = check_Greedy( z,C,NM )
%%
%Function:find the maximum matching in the linking and dyanmic graph
%Input:   z:the structure of network
%         C:target nodes
%         NM:the maximum iterted number
%Output:
%         TK:the maximum matching in the linking and dyanmic graph
TK=cell(NM,1);
R0=C;
N=max(max(z));
M=size(z);
T=M(1,1);
zz=zeros(N);
yy=[];
r=1;
for i=1:T
zz(z(i,2),z(i,1))=1;
end
g=zz;
KK=[];
MKK1=[];
Q=1;
CC=C;
r_repeat=1;
while Q
    
RR{r,1}=R0;    
  
%R0is the right target nides in the N step
m3=length(R0);
k=1;E=[];
for i=1:length(z)
    [x1,y1]=ismember(z(i,2),R0);
    if x1~=0
        E(k,:)=z(i,:);k=k+1;
    end    
end


%the stop condition

if sum(sum(E))==0
    Q=0;
end

if sum(sum(E))~=0
% *************find the maximum mathcing in each iterted bipartite graph***********************

Z=[];
N=length(g);
Z(:,1)=E(:,1);Z(:,2)=E(:,2)+N;
B=[];
[c,d]=size(Z);
for i=1:c
    B(Z(i,1),Z(i,2))=1;
    B(Z(i,2),Z(i,1))=1;
end
B=sparse(B);

F = matching(B);
f=[];
f(:,1)=[1:N]';
f(:,2)=F(1:N,1);
PP=[];kk=1;
for i=1:length(f)
    if f(i,2)~=0
        PP(kk,1)=f(i,1);PP(kk,2)=f(i,2)-N;
        kk=kk+1;
    end
end
M=zeros(N);
[oo1,oo2]=size(PP);
for i=1:oo1
    M(PP(i,1),PP(i,2))=1;
end


% [M,result] = Greedy_markov( F,CC,Z,E,g,N,NM );
   I=1;K=[];
    [a,b]=size(M);
for i=1:a
    [x,y]=find(M(i,:)~=0);
    if length(x)~=0
        K(I,1)=i; K(I,2)=y;
        I=I+1;
    end
end
Q=1;
m1=length(MKK1);
R0=K(:,1);
CC=E(:,1);


m4=length(R0);

TK{r,1}=K;

KK=[KK;K];
MKK=unique(KK,'rows');
MKK1=MKK;
r=r+1;
m2=length(MKK1);


if (m1==m2) && (m3==m4) 
    r_repeat=r_repeat+1;
else
    r_repeat=0;
end



if r_repeat>=50
Q=0;
end


end


end



 Mark=[];
for i=1:length(TK)
       
               if length(TK{i,1})==0
                   Mark(i,1)=1;
               end
               if length(TK{i,1})~=0
                   Mark(i,1)=0;
               end
 end
    [sv1,sg1]=find(Mark==1);
    
    
   TK(sv1)=[];


 RR=RR(1:length(TK));  
  
   
end

